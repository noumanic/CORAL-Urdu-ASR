Urdu Audio Dataset
=====================
Total Recordings: 1
Generated: 2025-10-05 14:14:33

File Structure:
- *.webm/*.mp3: Audio recordings
- *.json: Metadata for each recording

This dataset was collected using the Real-Time Urdu Speech Recognition System.
